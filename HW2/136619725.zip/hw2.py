import numpy as np
import torch
import hw2_utils as utils
import matplotlib.pyplot as plt

'''
    Important
    ========================================
    The autograder evaluates your code using FloatTensors for all computations.
    If you use DoubleTensors, your results will not match those of the autograder
    due to the higher precision.

    PyTorch constructs FloatTensors by default, so simply don't explicitly
    convert your tensors to DoubleTensors or change the default tensor.

'''


# Problem Linear Regression
def linear_gd(X, Y, lrate=0.01, num_iter=1000):
    '''
    Arguments:
        X (n x d FloatTensor): the feature matrix
        Y (n x 1 FloatTensor): the labels
        lrate (float, default: 0.01): learning rate
        num_iter (int, default: 1000): iterations of gradient descent to perform

    Returns:
        (d + 1) x 1 FloatTensor: the parameters w'
    '''
    n, d = X.shape
    w = torch.zeros((d, 1))
    w0 = torch.zeros((1, 1))
    for iter in range(num_iter):
        y = X @ w + w0
        w -= lrate * 2 * (X * (y - Y)).sum(axis=0).reshape(-1, 1) / n
        w0 -= lrate * 2 * (y - Y).sum() / n
    w = torch.cat((w0, w), 0)
    return w


def linear_normal(X, Y):
    '''
    Arguments:
        X (n x d FloatTensor): the feature matrix
        Y (n x 1 FloatTensor): the labels

    Returns:
        (d + 1) x 1 FloatTensor: the parameters w'

    '''
    n, d = X.shape
    X = torch.cat((torch.ones((n, 1)), X), 1)
    return torch.pinverse(X) @ Y


def plot_linear():
    '''
        Returns:
            Figure: the figure plotted with matplotlib
    '''
    X, Y = utils.load_reg_data()
    w = linear_normal(X, Y)
    Y_pred = X @ w[1:] + w[0]
    plt.scatter(X.flatten(), Y.flatten())
    plt.plot(X.flatten(), Y_pred.flatten())
    return plt.gcf()


# Problem Logistic Regression
def logistic(X, Y, lrate=.01, num_iter=1000):
    '''
    Arguments:
        X (n x d FloatTensor): the feature matrix
        Y (n x 1 FloatTensor): the labels
        lrate (float, default: 0.01): learning rate
        num_iter (int, default: 1000): iterations of gradient descent to perform

    Returns:
        (d + 1) x 1 FloatTensor: the parameters w'

    '''
    n, d = X.shape
    w = torch.zeros((d, 1))
    w0 = torch.zeros((1, 1))
    for iter in range(num_iter):
        y = X @ w + w0
        w -= (lrate * (-Y * X * torch.exp(-Y * y)) / (1 + torch.exp(-Y * y))).sum(axis=0).reshape(-1, 1) / n
        w0 -= (lrate * (-Y * torch.exp(-Y * y)) / (1 + torch.exp(-Y * y))).sum(axis=0).reshape(-1, 1) / n
    w = torch.cat((w0, w), 0)
    return w


def logistic_vs_ols():
    '''
    Returns:
        Figure: the figure plotted with matplotlib
    '''

    X, Y = utils.load_logistic_data()
    pos_idx = (Y == 1).flatten()
    neg_idx = (Y == -1).flatten()
    plt.scatter(X[pos_idx][:, 0], X[pos_idx][:, 1])
    plt.scatter(X[neg_idx][:, 0], X[neg_idx][:, 1])
    x_min, x_max = X[:, 0].min(), X[:, 0].max()
    x = np.linspace(x_min, x_max, 1000)

    w_linear = linear_normal(X, Y)
    w0, w1, w2 = w_linear.flatten()
    x2_linear = -(w0 + w1 * x) / w2
    w_logistic = logistic(X, Y)
    w0, w1, w2 = w_logistic.flatten()
    x2_logistic = -(w0 + w1 * x) / w2

    plt.plot(x, x2_linear, label='linear')
    plt.plot(x, x2_logistic, label='logistic')
    plt.legend()
    return plt.gcf()