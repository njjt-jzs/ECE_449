import hw3_utils
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import matplotlib.pyplot as plt

def svm_solver(x_train, y_train, lr, num_iters,
               kernel=hw3_utils.poly(degree=1), c=None):
    '''
    Computes an SVM given a training set, training labels, the number of
    iterations to perform projected gradient descent, a kernel, and a trade-off
    parameter for soft-margin SVM.

    Arguments:
        x_train: 2d tensor with shape (N, d).
        y_train: 1d tensor with shape (N,), whose elememnts are +1 or -1.
        lr: The learning rate.
        num_iters: The number of gradient descent steps.
        kernel: The kernel function.
           The default kernel function is 1 + <x, y>.
        c: The trade-off parameter in soft-margin SVM.
           The default value is None, referring to the basic, hard-margin SVM.

    Returns:
        alpha: a 1d tensor with shape (N,), denoting an optimal dual solution.
               Initialize alpha to be 0.
               Return alpha.detach() could possibly help you save some time
               when you try to use alpha in other places.

    Note that if you use something like alpha = alpha.clamp(...) with
    torch.no_grad(), you will have alpha.requires_grad=False after this step.
    You will then need to use alpha.requires_grad_().
    Alternatively, use in-place operations such as clamp_().
    '''
    n = len(x_train)
    if (c == None):
        c = float("inf")

    alpha = torch.zeros([n, 1], dtype=torch.float, requires_grad=True)
    K = torch.empty([n, n], dtype=torch.float)
    for i in range(n):
        for j in range(n):
            k = kernel(x_train[i], x_train[j])
            K[i][j] = k * y_train[i] * y_train[j]

    for i in range(num_iters):
        svm_dual = 1 / 2 * (alpha.T @ K @ alpha) - alpha.sum()
        svm_dual.backward()
        with torch.no_grad():
            alpha -= lr * alpha.grad
            torch.clamp_(alpha, min=0, max=c)
            alpha.grad.zero_()
    return alpha

def svm_predictor(alpha, x_train, y_train, x_test,
                  kernel=hw3_utils.poly(degree=1)):
    '''
    Returns the kernel SVM's predictions for x_test using the SVM trained on
    x_train, y_train with computed dual variables alpha.

    Arguments:
        alpha: 1d tensor with shape (N,), denoting an optimal dual solution.
        x_train: 2d tensor with shape (N, d), denoting the training set.
        y_train: 1d tensor with shape (N,), whose elements are +1 or -1.
        x_test: 2d tensor with shape (M, d), denoting the test set.
        kernel: The kernel function.
           The default kernel function is 1 + <x, y>.

    Return:
        A 1d tensor with shape (M,), the outputs of SVM on the test set.
    '''
    n = len(x_train)
    m = len(x_test)
    alpha_sup = alpha[alpha > 0]
    min_idx = torch.argmin(alpha_sup)
    K_b = torch.empty(len(alpha_sup))
    for i in range(len(alpha_sup)):
        K_b[i] = kernel(x_train[alpha > 0][i], x_train[alpha > 0][min_idx])
    b = 1 / y_train[alpha > 0][min_idx] - (alpha_sup * y_train[alpha > 0] * K_b).sum()

    K = torch.empty(n, m)
    for i in range(n):
        for j in range(m):
            K[i][j] = kernel(x_train[i], x_test[j])
    return torch.Tensor(alpha * y_train @ K + b)

class DigitsConvNet(nn.Module):
    def __init__(self):
        '''
        Initializes the layers of your neural network by calling the superclass
        constructor and setting up the layers.

        You should use nn.Conv2d, nn.MaxPool2D, and nn.Linear
        The layers of your neural network (in order) should be
        - A 2D convolutional layer (torch.nn.Conv2d) with 7 output channels, with kernel size 3
        - A 2D maximimum pooling layer (torch.nn.MaxPool2d), with kernel size 2
        - A 2D convolutional layer (torch.nn.Conv2d) with 3 output channels, with kernel size 2
        - A fully connected (torch.nn.Linear) layer with 10 output features

        '''
        super(DigitsConvNet, self).__init__()
        torch.manual_seed(0) # Do not modify the random seed for plotting!

        # Please ONLY define the sub-modules here
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=7, kernel_size=3)
        self.BN1 = nn.BatchNorm2d(num_features=7)
        self.relu1 = nn.ReLU()
        self.maxpool1 = nn.MaxPool2d(kernel_size=2)
        self.conv2 = nn.Conv2d(in_channels=7, out_channels=3, kernel_size=2)
        self.BN2 = nn.BatchNorm2d(num_features=3)
        self.relu2 = nn.ReLU()
        self.fc1 = nn.Linear(12, 10)

    def forward(self, xb):
        '''
        A forward pass of your neural network.

        Note that the nonlinearity between each layer should be F.relu.  You
        may need to use a tensor's view() method to reshape outputs

        Arguments:
            self: This object.
            xb: An (N,8,8) torch tensor.

        Returns:
            An (N, 10) torch tensor
        '''

        out = torch.unsqueeze(xb, 1)
        out = self.conv1(out)
        out = self.BN1(out)
        out = self.relu1(out)
        out = self.maxpool1(out)
        out = self.conv2(out)
        out = self.BN2(out)
        out = self.relu2(out)
        out = out.reshape(out.size(0), -1)
        out = self.fc1(out)

        return out

def fit_and_evaluate(net, optimizer, loss_func, train, test, n_epochs, batch_size=1):
    '''
    Fits the neural network using the given optimizer, loss function, training set
    Arguments:
        net: the neural network
        optimizer: a optim.Optimizer used for some variant of stochastic gradient descent
        train: a torch.utils.data.Dataset
        test: a torch.utils.data.Dataset
        n_epochs: the number of epochs over which to do gradient descent
        batch_size: the number of samples to use in each batch of gradient descent

    Returns:
        train_epoch_loss, test_epoch_loss: two arrays of length n_epochs+1,
        containing the mean loss at the beginning of training and after each epoch
    '''
    train_dl = torch.utils.data.DataLoader(train, batch_size)
    test_dl = torch.utils.data.DataLoader(test)

    train_losses = []
    test_losses = []
    with torch.no_grad():
        net.eval()
        train_losses.append(hw3_utils.epoch_loss(net, loss_func, train_dl))
        test_losses.append(hw3_utils.epoch_loss(net, loss_func, test_dl))

    for epoch in range(n_epochs):
        net.train()
        for i, (xb, yb) in enumerate(train_dl):
            hw3_utils.train_batch(net, loss_func, xb, yb, optimizer)
        with torch.no_grad():
            net.eval()
            train_losses.append(hw3_utils.epoch_loss(net, loss_func, train_dl))
            test_losses.append(hw3_utils.epoch_loss(net, loss_func, test_dl))


    # Compute the loss on the training and validation sets at the start,
    # being sure not to store gradient information (e.g. with torch.no_grad():)

    # Train the network for n_epochs, storing the training and validation losses
    # after every epoch. Remember not to store gradient information while calling
    # epoch_loss

    return train_losses, test_losses

