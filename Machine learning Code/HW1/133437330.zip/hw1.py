import torch
import hw1_utils as utils


# Problem Naive Bayes
def bayes_MAP(X, y):
    '''
    Arguments:
        X (N x d LongTensor): features of each object, X[i][j] = 0/1
        y (N LongTensor): label of each object, y[i] = 0/1

    Returns:
        theta (2 x d Float Tensor): MAP estimation of P(X_j=1|Y=i)

    ''' 
    d = X.shape[1]
    result = torch.zeros((2,d))
    for i in [0,1]:
        X_i = X[y == i]
        result[i] = X_i.sum(axis=0)/X_i.shape[0]
    return result 
        
           

    
    pass

def bayes_MLE(y):
    '''
    Arguments:
        y (N LongTensor): label of each object

    Returns:
        p (float or scalar Float Tensor): MLE of P(Y=0)

    '''
 #   N = len(y)
 #   one = (y == 0).sum(dim=0)
 #   p = one/N
 #   return p
     
    return torch.sum (y == 0)/len(y) 

    pass
def bayes_classify(theta, p, X):
    '''
    Arguments:
        theta (2 x d Float Tensor): returned value of `bayes_MAP`
        p (float or scalar Float Tensor): returned value of `bayes_MLE`
        X (N x d LongTensor): features of each object for classification, X[i][j] = 0/1

    Returns:
        y (N LongTensor): label of each object for classification, y[i] = 0/1
    
    '''

    y=[]
    for sample in X:
        y_0=0
        for j,x_j in enumerate(sample):
            y_0+=torch.log(theta[0][j]) if x_j==1 else torch.log(1-theta[0][j])
        y_0+=torch.log(p)

        y_1=0
        for j,x_j in enumerate(sample):
            y_1+=torch.log(theta[1][j]) if x_j==1 else torch.log(1-theta[1][j])
        y_1+=torch.log(1-p)

        y.append(1 if y_1>=y_0 else 0)
    return torch.Tensor(y)

# Problem Gaussian Naive Bayes
def gaussian_MAP(X, y):
    '''
    Arguments:
        X (N x d FloatTensor): features of each object
        y (N LongTensor): label of each object, y[i] = 0/1

    Returns:
        mu (2 x d Float Tensor): MAP estimation of mu in N(mu, sigma2)
        sigma2 (2 x d Float Tensor): MAP estimation of mu in N(mu, sigma2)

    '''
    d = X.shape[1]
    mu = torch.zeros((2,d))
    sigma2 = torch.zeros((2,d))
    for i in [0,1]:
        X_i = X[y == i]
        mu[i] = torch.mean(X_i, axis = 0)
        sigma2[i] = torch.var(X_i, axis = 0, unbiased=False)
    return (mu, sigma2) 
        
    pass

def gaussian_MLE(y):
    '''
    Arguments:
        y (N LongTensor): label of each object

    Returns:
        p (float or scalar Float Tensor): MLE of P(Y=0)

    '''
    return torch.sum (y == 0)/len(y) 
    pass

def gaussian_classify(mu, sigma2, p, X):
    '''
    Arguments:
        mu (2 x d Float Tensor): returned value #1 of `gaussian_MAP`
        sigma2 (2 x d Float Tensor): returned value #2 of `gaussian_MAP`
        p (float or scalar Float Tensor): returned value of `bayes_MLE`
        X (N x d LongTensor): features of each object for classification, X[i][j] = 0/1

    Returns:
        y (N LongTensor): label of each object for classification, y[i] = 0/1
    
    '''
def gaussian_classify(mu, sigma2, p, X):
    '''
    Arguments:
        mu (2 x d Float Tensor): returned value #1 of `gaussian_MAP`
        sigma2 (2 x d Float Tensor): returned value #2 of `gaussian_MAP`
        p (float or scalar Float Tensor): returned value of `bayes_MLE`
        X (N x d LongTensor): features of each object for classification, X[i][j] = 0/1

    Returns:
        y (N LongTensor): label of each object for classification, y[i] = 0/1
    
    '''
    y = []
    for sample in X:
        temp=(-(sample - mu) ** 2 / (2 * sigma2) + torch.log(1 / torch.sqrt(2 * torch.pi * sigma2))).sum(axis=1)
        temp[0]+=torch.log(p)
        temp[1]+=torch.log(1-p)
        y.append(temp.argmax())
    return torch.Tensor(y)

# X, y = utils.gaussian_dataset("train")
# u,s = gaussian_MAP(X, y)
# p = gaussian_MLE(y)
# Xtest, ytest = utils.gaussian_dataset("test")
# ypred = gaussian_classify(u,s, p, Xtest)
# from sklearn.metrics import accuracy_score
# print(accuracy_score(ytest,ypred))


