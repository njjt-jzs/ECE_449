import torch
import hw4_utils
import numpy as np

def k_means(X=None, init_c=None, n_iters=50):
    """K-Means.

    Argument:
        X: 2D data points, shape [N, 2].
        init_c: initial centroids, shape [2, 2]. Each row is a centroid.
    
    Return:
        c: shape [2, 2]. Each row is a centroid.
    """

    if X is None:
        X, init_c = hw4_utils.load_data()
    current_c = torch.clone(init_c)
    bag_1 = set()
    bag_2 = set()
    converge = False

    while converge == False:
        x_1 = []
        x_2 = []
        new_bag_1 = set()
        new_bag_2 = set()
        cost = 0
        for i in range(len(X)):
            if (torch.sum(torch.square(X[i] - current_c[0])) < torch.sum(torch.square(X[i] - current_c[1]))):
                x_1.append(X[i])
                new_bag_1.add(i)
                cost += torch.sum(torch.square(X[i] - current_c[0]))
            else:
                x_2.append(X[i])
                new_bag_2.add(i)
                cost += torch.sum(torch.square(X[i] - current_c[1]))
        print("Cost: ", cost)
        hw4_utils.vis_cluster(current_c, torch.stack(x_1,0), torch.stack(x_2,0))
        new_c = torch.clone(current_c)
        new_c[0] = torch.mean(torch.stack(x_1,0), dim=0)
        new_c[1] = torch.mean(torch.stack(x_2,0), dim=0)
        if new_bag_1 == bag_1 and new_bag_2 == bag_2:
            converge = True
            return new_c
        else:
            bag_1 = new_bag_1.copy()
            bag_2 = new_bag_2.copy()
            current_c = torch.clone(new_c)
